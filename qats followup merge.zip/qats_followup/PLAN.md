# QATS Follow-up + RCA Merge - Files to generate
1. config/db.php         - migration patch (new columns on nc_followups)
2. includes/audit_functions.php - save_audit() NC creation update  
3. followup.php          - full unified page
4. includes/_sidebar.php - merge nav
5. includes/auth.php     - dept redirect
