<?php
// ============================================================
//  PATCH: includes/auth.php
//  Add department-based redirect after successful login.
//  Find the login() function's success block and add
//  the redirect logic below.
// ============================================================

// ── Inside login() after session is set, REPLACE the redirect ──
//
//   header('Location: dashboard.php'); exit;
//
// ── WITH ──

function _post_login_redirect(array $user): void
{
    $role       = strtolower($user['role']   ?? '');
    $dept       = strtolower($user['department'] ?? '');
    $can_admin  = !empty($user['can_admin']);
    $can_audit  = !empty($user['can_audit']);

    // PQC / Admin / roles that can audit go to dashboard
    $pqc_roles  = ['admin', 'pqc', 'quality'];
    $pqc_depts  = ['pqc', 'quality', 'qa'];

    $is_pqc = $can_admin
           || in_array($role, $pqc_roles, true)
           || in_array($dept, $pqc_depts, true);

    if ($is_pqc) {
        header('Location: dashboard.php');
    } else {
        // Department head / production / maintenance → straight to Follow-up
        header('Location: followup.php');
    }
    exit;
}

// ── requireLogin() — add dept check for mid-session page access ──
//
//   Replace existing requireLogin() body with:

function requireLogin(): array
{
    if (empty($_SESSION['qats_user'])) {
        $back = urlencode($_SERVER['REQUEST_URI'] ?? '');
        header("Location: login.php?redirect=$back");
        exit;
    }
    return $_SESSION['qats_user'];
}

// Restrict dashboard.php to PQC/admin only (non-PQC get bounced)
function requireDashboardAccess(): void
{
    $user = requireLogin();
    $dept = strtolower($user['department'] ?? '');
    $role = strtolower($user['role']       ?? '');
    $pqc  = ['pqc','quality','qa','admin'];
    if (!in_array($dept,$pqc,true) && !in_array($role,$pqc,true) && empty($user['can_admin'])) {
        header('Location: followup.php');
        exit;
    }
}
