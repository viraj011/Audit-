<?php
// ============================================================
//  followup.php  —  Unified Follow-up & RCA Module
//  Replaces both nc_followup.php and rca.php
// ============================================================
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/components.php';

$user    = requireLogin();
$db      = db();

$userDept    = trim($user['department'] ?? '');
$userGenId   = $user['gen_id'] ?? '';
$userRole    = strtolower($user['role'] ?? '');
$can_admin   = !empty($user['can_admin']);
$isPQC       = $can_admin
            || in_array($userRole, ['admin','pqc','quality'], true)
            || in_array(strtolower($userDept), ['pqc','quality','qa'], true);

// ── Upload dir ──────────────────────────────────────────────
$uploadDir = __DIR__ . '/uploads/nc_evidence/';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

// ============================================================
//  POST HANDLERS
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $ncId   = (int)($_POST['nc_id'] ?? 0);

    // ── Department: Save RCA / update single NC ──────────────
    if ($action === 'dept_save' && $ncId > 0) {

        // Verify ownership (dept users can only update their dept's NCs)
        if (!$isPQC) {
            $own = $db->prepare("SELECT id FROM nc_followups WHERE id=? AND department=?");
            $own->execute([$ncId, $userDept]);
            if (!$own->fetchColumn()) { flash('error','Access denied.'); header('Location: followup.php'); exit; }
        }

        $rootCause  = trim($_POST['root_cause']        ?? '');
        $corrAction = trim($_POST['corrective_action'] ?? '');
        $responsible= trim($_POST['responsible']       ?? '');
        $rcaNotes   = trim($_POST['rca_notes']         ?? '');
        $closeDate  = trim($_POST['completion_date']   ?? '') ?: null;
        $newStatus  = $_POST['status'] ?? 'in_progress';

        // Validate status transition
        $allowed = ['pending','in_progress','submitted'];
        if (!in_array($newStatus, $allowed, true)) $newStatus = 'in_progress';

        // Evidence upload
        $evidencePath = null; $evidenceName = null;
        if (!empty($_FILES['evidence']['name'])) {
            $ext      = strtolower(pathinfo($_FILES['evidence']['name'], PATHINFO_EXTENSION));
            $allowed_ext = ['jpg','jpeg','png','pdf','xlsx','xls','docx','doc'];
            if (in_array($ext, $allowed_ext, true) && $_FILES['evidence']['error'] === UPLOAD_ERR_OK) {
                $fname        = 'nc_' . $ncId . '_' . time() . '.' . $ext;
                $dest         = $uploadDir . $fname;
                if (move_uploaded_file($_FILES['evidence']['tmp_name'], $dest)) {
                    $evidencePath = 'uploads/nc_evidence/' . $fname;
                    $evidenceName = $_FILES['evidence']['name'];
                }
            }
        }

        $submittedAt = ($newStatus === 'submitted') ? date('Y-m-d H:i:s') : null;
        $submittedBy = ($newStatus === 'submitted') ? $userGenId           : null;

        $upd = $db->prepare("
            UPDATE nc_followups SET
                root_cause          = :rc,
                corrective_action   = :ca,
                responsible         = :resp,
                rca_notes           = :notes,
                completion_date     = :cdate,
                status              = :status,
                submitted_by        = COALESCE(:sby, submitted_by),
                submitted_at        = COALESCE(:sat, submitted_at),
                evidence_path       = COALESCE(:epath, evidence_path),
                evidence_name       = COALESCE(:ename, evidence_name)
            WHERE id = :id
        ");
        $upd->execute([
            ':rc'     => $rootCause   ?: null,
            ':ca'     => $corrAction  ?: null,
            ':resp'   => $responsible ?: null,
            ':notes'  => $rcaNotes    ?: null,
            ':cdate'  => $closeDate,
            ':status' => $newStatus,
            ':sby'    => $submittedBy,
            ':sat'    => $submittedAt,
            ':epath'  => $evidencePath,
            ':ename'  => $evidenceName,
            ':id'     => $ncId,
        ]);

        flash('success', $newStatus === 'submitted'
            ? 'Follow-up submitted for QA verification.'
            : 'Follow-up saved successfully.');
        header('Location: followup.php#nc-' . $ncId);
        exit;
    }

    // ── PQC: Verify single or bulk ───────────────────────────
    if ($action === 'verify' && $isPQC) {
        $ids = isset($_POST['nc_ids']) ? array_map('intval', (array)$_POST['nc_ids']) : ($ncId ? [$ncId] : []);
        if ($ids) {
            $ph = implode(',', array_fill(0, count($ids), '?'));
            $p  = array_merge([$userGenId, date('Y-m-d H:i:s')], $ids);
            $db->prepare("UPDATE nc_followups SET status='verified', verified_by=?, verified_at=? WHERE id IN ($ph)")->execute($p);
            flash('success', count($ids) . ' NC(s) marked as Verified & Closed.');
        }
        header('Location: followup.php');
        exit;
    }

    // ── PQC: Reject ─────────────────────────────────────────
    if ($action === 'reject' && $isPQC && $ncId > 0) {
        $reason = trim($_POST['rejection_reason'] ?? '');
        $db->prepare("UPDATE nc_followups SET status='rejected', rejection_reason=?, verified_by=?, verified_at=? WHERE id=?")
           ->execute([$reason ?: 'Rejected by QA.', $userGenId, date('Y-m-d H:i:s'), $ncId]);
        flash('success', 'NC rejected. Department notified.');
        header('Location: followup.php');
        exit;
    }

    // ── PQC: Bulk verify all submitted ──────────────────────
    if ($action === 'verify_all_submitted' && $isPQC) {
        $db->prepare("UPDATE nc_followups SET status='verified', verified_by=?, verified_at=? WHERE status='submitted'")
           ->execute([$userGenId, date('Y-m-d H:i:s')]);
        flash('success', 'All submitted NCs verified and closed.');
        header('Location: followup.php');
        exit;
    }
}

// ============================================================
//  FILTERS
// ============================================================
$fStatus  = $_GET['status']  ?? 'active';   // active | verified | all
$fDept    = $_GET['dept']    ?? '';
$fBlock   = $_GET['block']   ?? '';
$fLine    = $_GET['line']    ?? '';
$fStage   = $_GET['stage']   ?? '';
$fDateFrom= $_GET['from']    ?? '';
$fDateTo  = $_GET['to']      ?? '';
$fSearch  = trim($_GET['q']  ?? '');

// ============================================================
//  QUERY  nc_followups
// ============================================================
$params = [];
$where  = "WHERE 1=1";

// Dept restriction for non-PQC
if (!$isPQC) {
    $where .= " AND nf.department = ?";
    $params[] = $userDept;
} elseif ($fDept !== '') {
    $where .= " AND nf.department = ?";
    $params[] = $fDept;
}

// Status filter
if ($fStatus === 'active') {
    $where .= " AND nf.status NOT IN ('verified','closed')";
} elseif ($fStatus === 'closed') {
    $where .= " AND nf.status IN ('verified','closed')";
}
// 'all' = no filter

if ($fBlock !== '') { $where .= " AND nf.block = ?";  $params[] = $fBlock; }
if ($fLine  !== '') { $where .= " AND nf.line  = ?";  $params[] = $fLine; }
if ($fStage !== '') { $where .= " AND nf.stage = ?";  $params[] = $fStage; }
if ($fDateFrom !== '') { $where .= " AND DATE(nf.created_at) >= ?"; $params[] = $fDateFrom; }
if ($fDateTo   !== '') { $where .= " AND DATE(nf.created_at) <= ?"; $params[] = $fDateTo; }
if ($fSearch !== '') {
    $where .= " AND (nf.param LIKE ? OR nf.finding LIKE ? OR nf.audit_code LIKE ? OR nf.line LIKE ?)";
    $s = '%' . $fSearch . '%';
    array_push($params, $s, $s, $s, $s);
}

$sql = "
    SELECT
        nf.*,
        a.model, a.shift, a.pass_rate,
        a.created_at AS audit_date
    FROM nc_followups nf
    LEFT JOIN audits a ON a.id = nf.audit_id
    $where
    ORDER BY
        FIELD(nf.status,'pending','rejected','in_progress','submitted','verified','closed'),
        nf.due_date ASC,
        nf.created_at DESC
";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$allNCs = $stmt->fetchAll(PDO::FETCH_ASSOC);

// ── KPI counts ──────────────────────────────────────────────
$kpiBase   = !$isPQC ? "WHERE department = " . $db->quote($userDept) : "WHERE 1=1";
$kpi       = $db->query("
    SELECT
        COUNT(*) AS total,
        SUM(status='pending')     AS pending,
        SUM(status='in_progress') AS in_progress,
        SUM(status='submitted')   AS submitted,
        SUM(status='rejected')    AS rejected,
        SUM(status IN ('verified','closed')) AS closed,
        SUM(status NOT IN ('verified','closed') AND due_date < CURDATE()) AS overdue
    FROM nc_followups $kpiBase
")->fetch(PDO::FETCH_ASSOC);

// ── Grouping for display ─────────────────────────────────────
// Group by department (PQC view) then by stage within each dept
$grouped = [];
foreach ($allNCs as $nc) {
    $dept  = $nc['department'] ?: 'Unassigned';
    $stage = $nc['stage']      ?: 'General';
    $grouped[$dept][$stage][] = $nc;
}
ksort($grouped);

// ── Distinct filter options ──────────────────────────────────
$depts  = $db->query("SELECT DISTINCT department FROM nc_followups WHERE department IS NOT NULL AND department<>'' ORDER BY department")->fetchAll(PDO::FETCH_COLUMN);
$blocks = ['A','B','C','D','E'];
$stages = $db->query("SELECT DISTINCT stage FROM nc_followups WHERE stage IS NOT NULL AND stage<>'' ORDER BY stage")->fetchAll(PDO::FETCH_COLUMN);
$lines  = $db->query("SELECT name FROM production_lines WHERE active=1 ORDER BY sort_order")->fetchAll(PDO::FETCH_COLUMN);

$pageTitle = 'Follow-up & RCA';
?>
